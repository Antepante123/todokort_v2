package com.example.todokort

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
