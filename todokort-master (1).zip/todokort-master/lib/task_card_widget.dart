/*import 'package:flutter/material.dart';
import 'package:todokort/create_task.dart';
import 'package:todokort/model.dart';
import 'package:http/http.dart' as http;

class TaskCardWidget extends StatelessWidget {
  final TaskCard card;
  TaskCardWidget(this.card);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      width: 300,
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Text("Here you can add a task you wish to complete"),
      ),
    );
  }
}
*/